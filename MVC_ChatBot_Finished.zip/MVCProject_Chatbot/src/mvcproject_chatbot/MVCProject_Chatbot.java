package mvcproject_chatbot;
//Brandon Hillenbrand
//MVC project: ChatBot
//bmh5582
import java.io.FileNotFoundException;
public class MVCProject_Chatbot {
    
    
    public static void main(String[] args) throws FileNotFoundException{
        ChatBotController cbc = new ChatBotController();
    }
    
}
